<?php
$conn = new mysqli("localhost", "root", "", "fbapp");
session_start();
?>
