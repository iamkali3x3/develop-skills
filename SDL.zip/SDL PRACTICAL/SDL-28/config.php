<?php
$conn = new mysqli("localhost", "root", "", "email_verification");
?>
