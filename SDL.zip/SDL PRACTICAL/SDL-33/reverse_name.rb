# Ruby program to accept first and last name and print them in reverse order

# Accept first and last name from user input
print "Enter your first name: "
first_name = gets.chomp

print "Enter your last name: "
last_name = gets.chomp

# Print names in reverse order
puts "#{last_name} #{first_name}"
